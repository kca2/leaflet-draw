is.bathy = function(xyz){
	print(class(xyz) == "bathy")
}